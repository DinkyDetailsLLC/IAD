//
//  MyScene.m
//  SpriteKit
//
//  Created by DANIEL ANNIS on 5/7/14.
//  Copyright (c) 2014 Dinky_Details. All rights reserved.
//
#import <Foundation/Foundation.h>

@interface NSTimer (Pausing)

// Pause
- (void)pause;
// Resume
- (void)resume;

@end
